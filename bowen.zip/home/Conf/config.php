<?php
return array(
		
	'DB_DSN' => 'mysql://root:@localhost:3306/distribution',//使用DSN方式配置数据库信息
	'DB_PREFIX' => '',
	'SHOW_PAGE_TRACE' => True,

);
?>