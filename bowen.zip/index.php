<?php

define('APP_DEBUG','TRUE'); 
define('THINK_PATH','./ThinkPHP/');
define('APP_PATH','./home/');
define('APP_NAME','home');
define('ENGINE_NAME','cluster');
require THINK_PATH.'ThinkPHP.php';

?>
